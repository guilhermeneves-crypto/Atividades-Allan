function verificaoUser(vetorex) {
  const vetor = vetorex;

  for (let i = 0; i <= 4; i++) {
    if (
      vetor.nome.length > 3 &&
      vetor.idade >= 18 &&
      vetor.email.indexOf("@") != -1
    ) {
      return "CADASTRO_OK";
    } else {
      return "DADOS_INVALIDOS";
    }
  }
}
function calcularCarrinho(produtos) {
  let soma = 0;
  for (i = 0; i < produtos.length; i++) {
    soma = soma + produtos[i];
  }
  if (soma >= 100) {
    return soma * 0.9;
  } else {
    return soma;
  }
}
function countProducts(produto, categoria) {
  let total = 0;
  for (i = 0; i < produto.length; i++) {
    if (produto[i].categoria == categoria) {
      total++;
    }
  }
  return total;
}
const vetor1 = { nome: "nome123", idade: 20, email: "email@gmail.com" };
const precos = [10, 20, 20, 90, 80];
const produtos1 = [
  { nome: "TV", categoria: "eletronico" },
  { nome: "SLA", categoria: "HAHA" },
  { nome: "ALGO", categoria: "eletronico" },
];
const categoria = "eletronico";
if (verificaoUser(vetor1) === "CADASTRO_OK") {
  console.log("Teste 1 Passou");
} else {
  console.log("Teste 1 Não Passou");
}
if (calcularCarrinho(precos) === 198) {
console.log("Teste 2 Passou");
} else {
  console.log("Teste 2 Não Passou");
}
if(countProducts(produtos1, categoria) === 2){
  console.log("Teste 3 Passou");
} else {
  console.log("Teste 3 Não Passou");
}
